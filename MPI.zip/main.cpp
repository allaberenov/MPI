#include <mpi.h>
#include <iostream>
#include <iomanip>


int main(int argc, char **argv) {
    int N = 100000000;
//    std::cin >> N;
    MPI_Init(&argc, &argv);

    double delta = 1.0 / N;

    int proc_id, num_procs;
    MPI_Comm_rank(MPI_COMM_WORLD, &proc_id);
    MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

    int p = N / num_procs;

    if (proc_id == 0) {
        auto time = MPI_Wtime();
        double total_integral = 0, sub_integral = 0;
        for (auto i = 0; i < N; ++i) {
            double x = (i + (i + 1)) * delta / 2;
            sub_integral = delta * (4 / (1 + x * x));
            total_integral += sub_integral;
        }


        std::cout << "I_0(calculating sequentially by main process) = " << total_integral << "\n";
        std::cout << "Time of I_0(calculating sequentially by main process): " << std::fixed << std::setprecision(15)
                  << MPI_Wtime() - time << "\n";
        auto res = MPI_Wtime() - time;

        time = MPI_Wtime();
        for (auto i = 1; i < num_procs; ++i) {
            double left_border = i * p * delta;
            double right_border = (i + 1) * p * delta;
            MPI_Send(&left_border, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
            MPI_Send(&right_border, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
        }

        total_integral = 0;
        sub_integral = 0;

        for (int i = 0; i < p; ++i) {
            double left_border = i * delta;
            double right_border = (i + 1) * delta;
            double x = (left_border + right_border) / 2;
            sub_integral = 4 / (1 + x * x) * delta;
            total_integral += sub_integral;
        }
        std::cout << "I_0 = " << total_integral << "\n";

        for (auto i = 1; i < num_procs; ++i) {
            sub_integral = 0;
            MPI_Recv(&sub_integral, 1, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            total_integral += sub_integral;
        }


        double left_border = num_procs * p * delta;
        for (int i = 0; i < (N % p); ++i) {
            double right_border = left_border + delta;
            double x = (left_border + right_border) / 2;
            sub_integral = 4 / (1 + x * x) * delta;
            total_integral += sub_integral;
            left_border = right_border;
        }

        std::cout << "I_0 + I_1 + I_2 + I_3 = " << total_integral << "\n";
        std::cout << "Time of calculating: " << std::fixed << std::setprecision(15) << MPI_Wtime() - time << "\n";
//        std::cout << '[' <<N << " [" << num_procs << ", "  <<res / (MPI_Wtime() - time) << "],\n";

    } else if (proc_id > 0 && proc_id < p) {
        double left_border = 0;
        double right_border = 0;
        double sub_integral = 0;
        MPI_Recv(&left_border, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        MPI_Recv(&right_border, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        for (; left_border < right_border;) {
            double x = (left_border + left_border + delta) / 2;
            sub_integral += 4 / (1 + x * x) * delta;
            left_border += delta;
        }

        int id;
        MPI_Comm_rank(MPI_COMM_WORLD, &id);
        std::cout << "I_" << id << " = " << sub_integral << '\n';
        MPI_Send(&sub_integral, 1, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);

    }
    MPI_Finalize();

    return 0;
}
